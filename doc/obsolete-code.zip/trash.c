/* This file contains routines no more used by ultradefrag engine. */

/**
 * @brief Retrieves a type of the file system 
 *        containing on the volume.
 * @details Sets the global partition_type variable.
 * @note This routine is not reliable because it may
 * detect NTFS_PARTITION while the partition 
 * is actually UDF-formatted.
 */
void CheckForNtfsPartition(void)
{
	PARTITION_INFORMATION *part_info;
	NTFS_DATA *ntfs_data;
	NTSTATUS status;
	IO_STATUS_BLOCK iosb;

	/* allocate memory */
	part_info = winx_heap_alloc(sizeof(PARTITION_INFORMATION));
	if(part_info == NULL){
		DebugPrint("Cannot allocate memory for CheckForNtfsPartition()!\n");
		out_of_memory_condition_counter ++;
		partition_type = FAT32_PARTITION;
		return;
	}
	ntfs_data = winx_heap_alloc(sizeof(NTFS_DATA));
	if(ntfs_data == NULL){
		winx_heap_free(part_info);
		DebugPrint("Cannot allocate memory for CheckForNtfsPartition()!\n");
		out_of_memory_condition_counter ++;
		partition_type = FAT32_PARTITION;
		return;
	}
	
	/*
	* Try to get fs type through IOCTL_DISK_GET_PARTITION_INFO request.
	* Works only on MBR-formatted disks. To retrieve information about 
	* GPT-formatted disks use IOCTL_DISK_GET_PARTITION_INFO_EX.
	*/
	RtlZeroMemory(part_info,sizeof(PARTITION_INFORMATION));
	status = NtDeviceIoControlFile(winx_fileno(fVolume),NULL,NULL,NULL,&iosb, \
				IOCTL_DISK_GET_PARTITION_INFO,NULL,0, \
				part_info, sizeof(PARTITION_INFORMATION));
	if(NT_SUCCESS(status)/* == STATUS_PENDING*/){
		(void)NtWaitForSingleObject(winx_fileno(fVolume),FALSE,NULL);
		status = iosb.Status;
	}
	if(NT_SUCCESS(status)){
		DebugPrint("Partition type: %u\n",part_info->PartitionType);
		if(part_info->PartitionType == 0x7){
			DebugPrint("NTFS found\n");
			partition_type = NTFS_PARTITION;
			winx_heap_free(part_info);
			winx_heap_free(ntfs_data);
			return;
		}
	} else {
		DebugPrint("Can't get fs info: %x!\n",(UINT)status);
	}

	/*
	* To ensure that we have a NTFS formatted partition
	* on GPT disks and when partition type is 0x27
	* FSCTL_GET_NTFS_VOLUME_DATA request can be used.
	*/
	RtlZeroMemory(ntfs_data,sizeof(NTFS_DATA));
	status = NtFsControlFile(winx_fileno(fVolume),NULL,NULL,NULL,&iosb, \
				FSCTL_GET_NTFS_VOLUME_DATA,NULL,0, \
				ntfs_data, sizeof(NTFS_DATA));
	if(NT_SUCCESS(status)/* == STATUS_PENDING*/){
		(void)NtWaitForSingleObject(winx_fileno(fVolume),FALSE,NULL);
		status = iosb.Status;
	}
	if(NT_SUCCESS(status)){
		DebugPrint("NTFS found\n");
		partition_type = NTFS_PARTITION;
		winx_heap_free(part_info);
		winx_heap_free(ntfs_data);
		return;
	} else {
		DebugPrint("Can't get ntfs info: %x!\n",status);
	}

	/*
	* Let's assume that we have a FAT32 formatted partition.
	* Currently we don't need more detailed information.
	*/
	partition_type = FAT32_PARTITION;
	DebugPrint("NTFS not found\n");
	winx_heap_free(part_info);
	winx_heap_free(ntfs_data);
}
